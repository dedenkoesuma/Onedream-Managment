<?php

namespace App\Filament\Widgets;

use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;
use App\Models\Finance;

class StatsOverviewSecondRow extends BaseWidget
{
    protected function getStats(): array
    {

        $total_keuangan = Finance::sum('id');

        $stat4 = Stat::make('Total Portofolio ', $total_keuangan)
        ->descriptionIcon('heroicon-m-rocket-launch')
        ->description('Total Portofolio Masuk')
        ->color('gray');
        return [$stat4];
    }
}
