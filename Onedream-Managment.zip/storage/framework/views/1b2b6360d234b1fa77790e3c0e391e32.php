<?php if (isset($component)) { $__componentOriginalb525200bfa976483b4eaa0b7685c6e24 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb525200bfa976483b4eaa0b7685c6e24 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-widgets::components.widget','data' => ['class' => 'fi-filament-info-widget']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('filament-widgets::widget'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'fi-filament-info-widget']); ?>
    <?php if (isset($component)) { $__componentOriginalee08b1367eba38734199cf7829b1d1e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee08b1367eba38734199cf7829b1d1e9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.section.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('filament::section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <div class="flex items-center gap-x-3">
            <div class="flex-1">
                <a
                    href="https://onedream.id"
                    rel="noopener noreferrer"
                    target="_blank"
                >
                <svg  xmlns="http://www.w3.org/2000/svg" width="200" height="85"  viewBox="480 400 534.01 451.88"><defs><style>.cls-1{fill:#fff;}.cls-2{isolation:isolate;}</style></defs><g class="cls-2"><path class="cls-1" d="m597.25,587.52c-6.22,0-12.06-1.24-17.53-3.71-5.47-2.47-10.29-5.9-14.45-10.28-4.16-4.38-7.42-9.44-9.78-15.2-2.36-5.76-3.55-11.92-3.55-18.48s1.18-12.73,3.55-18.48c2.36-5.76,5.62-10.82,9.78-15.2,4.16-4.38,8.97-7.8,14.45-10.28,5.47-2.47,11.31-3.71,17.53-3.71s12.13,1.24,17.6,3.71c5.47,2.47,10.29,5.9,14.44,10.28,4.16,4.38,7.41,9.44,9.75,15.2,2.34,5.76,3.51,11.92,3.51,18.48s-1.17,12.73-3.51,18.48c-2.34,5.76-5.59,10.82-9.75,15.2-4.16,4.38-8.97,7.8-14.44,10.28-5.47,2.47-11.34,3.71-17.6,3.71Zm0-18.12c3.72,0,7.22-.78,10.51-2.33,3.28-1.55,6.17-3.69,8.67-6.4,2.5-2.71,4.45-5.84,5.88-9.39,1.42-3.55,2.13-7.35,2.13-11.42s-.71-7.89-2.13-11.46c-1.42-3.57-3.38-6.7-5.88-9.39s-5.38-4.81-8.67-6.37c-3.28-1.55-6.79-2.33-10.51-2.33s-7.22.78-10.51,2.33c-3.28,1.55-6.17,3.69-8.67,6.4-2.5,2.71-4.46,5.84-5.88,9.39-1.42,3.55-2.13,7.35-2.13,11.42s.71,7.89,2.13,11.46c1.42,3.57,3.38,6.7,5.88,9.39,2.5,2.69,5.38,4.82,8.67,6.37,3.28,1.55,6.78,2.33,10.51,2.33Z"/><path class="cls-1" d="m716.09,544.05v41.76h-18.12v-36.77c0-2.32-.56-4.41-1.67-6.27-1.12-1.86-2.61-3.34-4.46-4.43-1.86-1.09-3.93-1.64-6.2-1.64s-4.36.55-6.24,1.64c-1.88,1.09-3.37,2.57-4.46,4.43-1.09,1.86-1.64,3.95-1.64,6.27v36.77h-18.12l-.07-65.66h18.12l.07,4.86c2.19-2.1,4.76-3.74,7.71-4.92s6.07-1.77,9.36-1.77c4.77,0,9.09,1.16,12.97,3.48,3.87,2.32,6.97,5.42,9.29,9.29,2.32,3.87,3.48,8.2,3.48,12.97Z"/><path class="cls-1" d="m756.8,587.52c-6.04,0-11.55-1.55-16.51-4.66-4.97-3.11-8.93-7.29-11.88-12.54-2.95-5.25-4.43-11.05-4.43-17.4,0-4.77.85-9.25,2.56-13.43,1.71-4.18,4.06-7.86,7.06-11.03,3-3.17,6.49-5.66,10.47-7.45,3.98-1.79,8.23-2.69,12.74-2.69,5.21,0,9.97,1.12,14.28,3.35,4.31,2.23,7.97,5.28,10.97,9.13,3,3.85,5.14,8.21,6.43,13.07,1.29,4.86,1.5,9.91.62,15.17h-45.57c.57,1.93,1.45,3.67,2.66,5.22,1.2,1.55,2.69,2.79,4.46,3.71s3.82,1.4,6.14,1.44c2.28.04,4.38-.48,6.3-1.58,1.93-1.09,3.57-2.56,4.92-4.4l18.52,4.27c-2.67,5.82-6.65,10.58-11.95,14.28-5.3,3.7-11.23,5.55-17.79,5.55Zm-13.92-41.89h27.91c-.57-2.19-1.53-4.16-2.89-5.91-1.36-1.75-2.99-3.13-4.89-4.14-1.9-1.01-3.97-1.51-6.2-1.51s-4.24.5-6.14,1.51c-1.9,1.01-3.52,2.38-4.86,4.1-1.34,1.73-2.31,3.71-2.92,5.94Z"/></g><g class="cls-2"><path class="cls-1" d="m554.57,705.87v-91.92h30.47c6.35,0,12.29,1.19,17.83,3.58,5.54,2.39,10.42,5.69,14.64,9.91,4.22,4.23,7.53,9.11,9.92,14.64,2.39,5.54,3.58,11.48,3.58,17.83s-1.19,12.29-3.58,17.83c-2.39,5.54-5.69,10.42-9.92,14.64-4.22,4.23-9.1,7.53-14.64,9.92-5.54,2.39-11.48,3.58-17.83,3.58h-30.47Zm18.12-18.12h12.34c3.76,0,7.32-.72,10.67-2.17,3.35-1.44,6.31-3.44,8.9-5.97,2.58-2.54,4.61-5.49,6.07-8.86,1.47-3.37,2.2-6.98,2.2-10.83s-.73-7.45-2.2-10.8c-1.47-3.35-3.48-6.3-6.04-8.86s-5.52-4.56-8.86-6.01c-3.35-1.45-6.93-2.17-10.74-2.17h-12.34v55.68Z"/><path class="cls-1" d="m642.29,705.87l-.07-65.66h18.12l.07,4.86c2.19-2.1,4.76-3.74,7.71-4.92,2.95-1.18,6.07-1.77,9.36-1.77,2.41,0,4.81.35,7.22,1.05l-7.16,18.32c-1.58-.66-3.17-.99-4.79-.99-2.28,0-4.36.55-6.24,1.64-1.88,1.09-3.37,2.57-4.46,4.43-1.09,1.86-1.64,3.95-1.64,6.27v36.77h-18.12Z"/><path class="cls-1" d="m717.67,707.58c-6.04,0-11.55-1.55-16.51-4.66-4.97-3.11-8.93-7.29-11.88-12.54-2.95-5.25-4.43-11.05-4.43-17.4,0-4.77.85-9.25,2.56-13.43,1.71-4.18,4.06-7.86,7.06-11.03,3-3.17,6.49-5.66,10.47-7.45,3.98-1.79,8.23-2.69,12.74-2.69,5.21,0,9.97,1.12,14.28,3.35,4.31,2.23,7.97,5.28,10.97,9.13,3,3.85,5.14,8.21,6.43,13.07,1.29,4.86,1.5,9.91.62,15.17h-45.57c.57,1.93,1.45,3.67,2.66,5.22,1.2,1.55,2.69,2.79,4.46,3.71s3.82,1.4,6.14,1.44c2.28.04,4.38-.48,6.3-1.58,1.93-1.09,3.57-2.56,4.92-4.4l18.52,4.27c-2.67,5.82-6.65,10.58-11.95,14.28-5.3,3.7-11.23,5.55-17.79,5.55Zm-13.92-41.89h27.91c-.57-2.19-1.53-4.16-2.89-5.91-1.36-1.75-2.99-3.13-4.89-4.14-1.9-1.01-3.97-1.51-6.2-1.51s-4.24.5-6.14,1.51c-1.9,1.01-3.52,2.38-4.86,4.1-1.34,1.73-2.31,3.71-2.92,5.94Z"/><path class="cls-1" d="m809.2,640.21h18.12v65.66h-18.19l-.85-6.83c-1.71,2.54-3.9,4.6-6.57,6.17-2.67,1.58-5.8,2.36-9.39,2.36-4.9,0-9.48-.92-13.72-2.76-4.25-1.84-7.99-4.38-11.23-7.62-3.24-3.24-5.77-6.99-7.58-11.26-1.82-4.27-2.72-8.85-2.72-13.76s.85-9.06,2.56-13.13,4.11-7.66,7.22-10.77,6.69-5.54,10.74-7.29c4.05-1.75,8.41-2.63,13.1-2.63,4.03,0,7.65.85,10.87,2.56s6.03,3.87,8.44,6.5l-.79-7.22Zm-17.33,49.97c2.98,0,5.67-.77,8.08-2.3,2.41-1.53,4.31-3.6,5.71-6.2,1.4-2.6,2.1-5.48,2.1-8.63s-.7-6.08-2.1-8.67c-1.4-2.58-3.31-4.64-5.71-6.17-2.41-1.53-5.1-2.3-8.08-2.3s-5.76.77-8.21,2.3c-2.45,1.53-4.4,3.6-5.84,6.2-1.44,2.61-2.17,5.48-2.17,8.63s.73,6.03,2.2,8.63c1.47,2.61,3.43,4.67,5.88,6.2,2.45,1.53,5.16,2.3,8.14,2.3Z"/><path class="cls-1" d="m840.45,705.87v-65.66h18.12v4.86c2.23-2.1,4.81-3.74,7.75-4.92,2.93-1.18,6.04-1.77,9.32-1.77,4.46,0,8.57,1.03,12.31,3.09,3.74,2.06,6.75,4.79,9.03,8.21,2.32-3.41,5.34-6.15,9.06-8.21,3.72-2.06,7.79-3.09,12.21-3.09,4.77,0,9.09,1.16,12.97,3.48,3.87,2.32,6.97,5.42,9.29,9.29,2.32,3.87,3.48,8.2,3.48,12.97v41.76h-18.12v-36.77c0-2.28-.56-4.34-1.67-6.2-1.12-1.86-2.59-3.35-4.43-4.46-1.84-1.12-3.9-1.67-6.17-1.67s-4.34.55-6.2,1.64-3.35,2.57-4.46,4.43c-1.12,1.86-1.67,3.95-1.67,6.27v36.77h-18.12v-36.77c0-2.32-.55-4.41-1.64-6.27-1.09-1.86-2.57-3.34-4.43-4.43-1.86-1.09-3.93-1.64-6.2-1.64s-4.28.56-6.14,1.67c-1.86,1.12-3.35,2.6-4.46,4.46-1.12,1.86-1.67,3.93-1.67,6.2v36.77h-18.12Z"/></g><path class="cls-1" d="m500.96,536.78c-14.98-27.46-43.77-44.53-75.06-44.52h-44.73c-7.51,0-13.6,6.09-13.6,13.6v17.31c0,7.51-6.09,13.61-13.6,13.61h-11.77c-47.23-.38-85.82,37.6-86.2,84.83-.38,47.23,37.6,85.82,84.83,86.2.46,0,.91,0,1.37,0h42.02c7.51,0,13.6-6.09,13.6-13.6v-17.3c0-7.52,6.1-13.62,13.62-13.62h14.46c47.23,0,85.52-38.28,85.53-85.51,0-14.33-3.6-28.43-10.47-41.01Zm-73.64,77.43c-.47,0-9.43-.51-10.65-.51-6.49,0-12.91,1.35-18.86,3.92-11.68,5.03-16.74,13.96-26.48,26.62-1.12,1.53-2.38,2.95-3.76,4.25-14.46,14.01-37.54,13.65-51.55-.81-14.01-14.46-13.65-37.54.81-51.55,6.45-6.25,14.99-9.9,23.97-10.25.81.1,7.27.46,11.14.46,16.51.02,31.83-8.61,40.38-22.73v-.05c1-1.65,5.04-8.47,5.5-9.02,12.84-15.52,35.83-17.69,51.35-4.84,15.52,12.84,17.69,35.83,4.84,51.35-6.61,7.99-16.32,12.79-26.68,13.19h0Z"/></svg>
                </a>
                 <p class="mt-2 text-xs text-gray-500 dark:text-gray-400">
                    OneDream Creative Indonesia
                </p>
            </div>

            <div class="flex flex-col items-end gap-y-1 hidden md:flex">
                <?php if (isset($component)) { $__componentOriginal549c94d872270b69c72bdf48cb183bc9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal549c94d872270b69c72bdf48cb183bc9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.link','data' => ['color' => 'gray','href' => 'mailto:kontak.onedream@gmail.com','icon' => 'heroicon-m-chat-bubble-left-right','iconAlias' => 'panels::widgets.filament-info.open-documentation-button','rel' => 'noopener noreferrer','target' => '_blank']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('filament::link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['color' => 'gray','href' => 'mailto:kontak.onedream@gmail.com','icon' => 'heroicon-m-chat-bubble-left-right','icon-alias' => 'panels::widgets.filament-info.open-documentation-button','rel' => 'noopener noreferrer','target' => '_blank']); ?>
                    <p class="text-xs ">kontak.onedream@gmail.com</p>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal549c94d872270b69c72bdf48cb183bc9)): ?>
<?php $attributes = $__attributesOriginal549c94d872270b69c72bdf48cb183bc9; ?>
<?php unset($__attributesOriginal549c94d872270b69c72bdf48cb183bc9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal549c94d872270b69c72bdf48cb183bc9)): ?>
<?php $component = $__componentOriginal549c94d872270b69c72bdf48cb183bc9; ?>
<?php unset($__componentOriginal549c94d872270b69c72bdf48cb183bc9); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginal549c94d872270b69c72bdf48cb183bc9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal549c94d872270b69c72bdf48cb183bc9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.link','data' => ['color' => 'gray','href' => 'https://wa.me/0812133698433','icon' => 'heroicon-m-user','rel' => 'noopener noreferrer','target' => '_blank']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('filament::link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['color' => 'gray','href' => 'https://wa.me/0812133698433','icon' => 'heroicon-m-user','rel' => 'noopener noreferrer','target' => '_blank']); ?>
                    <p class="text-xs">+628 12 1336 98433</p>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal549c94d872270b69c72bdf48cb183bc9)): ?>
<?php $attributes = $__attributesOriginal549c94d872270b69c72bdf48cb183bc9; ?>
<?php unset($__attributesOriginal549c94d872270b69c72bdf48cb183bc9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal549c94d872270b69c72bdf48cb183bc9)): ?>
<?php $component = $__componentOriginal549c94d872270b69c72bdf48cb183bc9; ?>
<?php unset($__componentOriginal549c94d872270b69c72bdf48cb183bc9); ?>
<?php endif; ?>
            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $attributes = $__attributesOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $component = $__componentOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__componentOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb525200bfa976483b4eaa0b7685c6e24)): ?>
<?php $attributes = $__attributesOriginalb525200bfa976483b4eaa0b7685c6e24; ?>
<?php unset($__attributesOriginalb525200bfa976483b4eaa0b7685c6e24); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb525200bfa976483b4eaa0b7685c6e24)): ?>
<?php $component = $__componentOriginalb525200bfa976483b4eaa0b7685c6e24; ?>
<?php unset($__componentOriginalb525200bfa976483b4eaa0b7685c6e24); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\Onedream-Managment\vendor\filament\filament\src\/../resources/views/widgets/filament-info-widget.blade.php ENDPATH**/ ?>